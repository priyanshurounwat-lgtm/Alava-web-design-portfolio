export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 backdrop-blur-md bg-black/60">
      <div className="flex items-center justify-between px-6 md:px-10 h-14 font-mono text-xs uppercase tracking-widest">
        <div className="flex items-center gap-3">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full rounded-full bg-signal animate-pulse-dot" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-signal" />
          </span>
          <span className="text-white">ALAVA SYSTEM</span>
          <span className="hidden md:inline text-white/30">​</span>
        </div>
        <nav className="hidden md:flex items-center gap-8 text-white/50">
          <a href="#works" className="hover:text-white transition-colors">WORKS</a>
          <a href="#stack" className="hover:text-white transition-colors">​About</a>
          <a href="#pipeline" className="hover:text-white transition-colors">​Services</a>
          <a href="#brief" className="hover:text-white transition-colors">​Contact</a>
        </nav>
        <a
          href="#brief"
          className="text-white hover:text-signal transition-colors"
        >
          [ ENGAGE SYSTEM ]
        </a>
      </div>
    </header>
  );
}
