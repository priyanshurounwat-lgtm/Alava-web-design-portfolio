import { useState } from "react";
import { SectionLabel } from "./WorkGallery";

export function IntakeForm() {
  const [sent, setSent] = useState(false);
  return (
    <section id="brief" className="border-b border-white/10">
      <div className="px-6 md:px-10 py-20 md:py-28">
        <SectionLabel index="04" label="INTAKE CORE" />
        <h2 className="font-display font-bold uppercase text-5xl md:text-8xl leading-[0.9] tracking-tight mt-6 mb-16">
          Secure the <span className="text-white/40">brief.</span>
        </h2>

        <div className="grid md:grid-cols-12 gap-12 md:gap-16 border-t border-white/10 pt-16">
          {/* Left: contact */}
          <div className="md:col-span-5 space-y-12 font-mono text-sm uppercase tracking-widest">
            <div>
              <div className="text-white/40 mb-3">// MAIL RELAY</div>
              <a href="mailto:engage@alava.studio" className="text-2xl md:text-3xl normal-case lowercase text-white hover:text-signal transition-colors break-all">
                engage@alava.studio
              </a>
            </div>
            <div>
              <div className="text-white/40 mb-3">// COORDINATES</div>
              <p className="text-white/80 leading-relaxed">
                ALAVA WEB DESIGNERS<br />
                VADODARA, GUJARAT — IN<br />
                22.3072° N, 73.1812° E
              </p>
            </div>
            <div>
              <div className="text-white/40 mb-3">// RESPONSE WINDOW</div>
              <p className="text-white/80">&lt; 24 HRS / WEEKDAYS</p>
            </div>
            <div className="pt-12 border-t border-white/10 text-xs text-white/40">
              © 2026 ALAVA WEB DESIGNERS<br />
              ALL SYSTEMS PROPRIETARY
            </div>
          </div>

          {/* Right: form */}
          <form
            className="md:col-span-7 space-y-10"
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
            }}
          >
            <Field label="IDENTITY / COMPANY NAME" name="name" />
            <Field label="SECURE MAIL RELAY" name="email" type="email" />

            <div>
              <label className="font-mono text-xs uppercase tracking-widest text-white/40 block mb-3">
                PROJECT SCOPE / CORE OBJECTIVES
              </label>
              <textarea
                rows={6}
                className="w-full bg-transparent border border-white/20 p-5 font-mono text-sm text-white placeholder:text-white/20 focus:border-white focus:outline-none transition-colors resize-none"
                placeholder="Outline the mission, scale, and timeline..."
              />
            </div>

            <button
              type="submit"
              className="w-full bg-white text-black font-mono uppercase tracking-[0.3em] text-sm md:text-base py-7 hover:bg-signal hover:text-black transition-colors duration-300"
            >
              {sent ? "// TRANSMISSION RECEIVED ✓" : "[ TRANSMIT BRIEF → ]"}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

function Field({ label, name, type = "text" }: { label: string; name: string; type?: string }) {
  return (
    <div>
      <label className="font-mono text-xs uppercase tracking-widest text-white/40 block mb-3">
        {label}
      </label>
      <input
        name={name}
        type={type}
        required
        className="w-full bg-transparent border-0 border-b border-white/20 py-3 font-mono text-base text-white placeholder:text-white/20 focus:border-white focus:outline-none transition-colors"
      />
    </div>
  );
}
