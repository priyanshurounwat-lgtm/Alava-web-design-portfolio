import { SectionLabel } from "./WorkGallery";

const phases = [
  { code: "PHASE 01", title: "THE SYSTEM DISCOVERY", desc: "Deep audit of brand DNA, user flows, and competitive vectors. We map the territory before drawing the blueprint." },
  { code: "PHASE 02", title: "INTERFACE BLUEPRINTING", desc: "Wireframe architecture, design system tokens, and component logic. Pixel-perfect Figma deliverables." },
  { code: "PHASE 03", title: "MOTION CORE COMPILING", desc: "Framer / GSAP interaction layers, scroll choreography, and micro-animations that earn their weight." },
  { code: "PHASE 04", title: "PRODUCTION DEPLOYMENT", desc: "Webflow / Next.js production build, performance hardening, CMS wiring, and launch handoff." },
];

export function Pipeline() {
  return (
    <section id="pipeline" className="border-b border-white/10">
      <div className="px-6 md:px-10 py-20 md:py-28">
        <SectionLabel index="03" label="DEPLOYMENT PIPELINE" />
        <h2 className="font-display font-bold uppercase text-5xl md:text-8xl leading-[0.9] tracking-tight mt-6 mb-20">
          The deployment <br />
          <span className="text-white/40">pipeline.</span>
        </h2>

        <div className="relative pl-8 md:pl-20">
          <div className="absolute left-2 md:left-8 top-0 bottom-0 w-px bg-white/10" />
          {phases.map((p) => (
            <div
              key={p.code}
              className="relative group py-10 md:py-14 border-t border-white/10 hover:bg-white/[0.03] transition-colors duration-300"
            >
              <span className="absolute -left-[26px] md:-left-[34px] top-12 h-3 w-3 bg-black border border-white/40 group-hover:bg-signal group-hover:border-signal transition-colors" />
              <div className="grid md:grid-cols-12 gap-6 items-start px-2 md:px-6">
                <div className="md:col-span-3 font-mono text-xs uppercase tracking-widest text-white/40 group-hover:text-signal transition-colors">
                  {p.code}
                </div>
                <h3 className="md:col-span-5 font-display font-bold uppercase text-3xl md:text-5xl tracking-tight leading-[0.95]">
                  {p.title}
                </h3>
                <p className="md:col-span-4 font-mono text-sm text-white/50 uppercase tracking-wide leading-relaxed">
                  {p.desc}
                </p>
              </div>
            </div>
          ))}
          <div className="border-t border-white/10" />
        </div>
      </div>
    </section>
  );
}
