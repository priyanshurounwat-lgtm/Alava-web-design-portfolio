import sabithImg from "@/assets/sabith-ma.png.asset.json";
import holisticImg from "@/assets/holistic-influence.png.asset.json";

type Work = {
  idx: string;
  title: string;
  stack: string;
  projectImageUrl: string;
  liveWebsiteUrl: string;
};

const works: Work[] = [
  {
    idx: "01",
    title: "FASCINATING MALABI",
    stack: "WEB EXPERIENCE / NETLIFY",
    projectImageUrl:
      "https://image.thum.io/get/width/1400/crop/900/https://fascinating-malabi-189af4.netlify.app",
    liveWebsiteUrl: "https://fascinating-malabi-189af4.netlify.app",
  },
  {
    idx: "02",
    title: "HARMONY DENTAL CLINIC",
    stack: "DENTAL CLINIC / NETLIFY",
    projectImageUrl:
      "https://image.thum.io/get/width/1400/crop/900/https://harmonydentalclinic.netlify.app",
    liveWebsiteUrl: "https://harmonydentalclinic.netlify.app",
  },
  {
    idx: "03",
    title: "HOLISTIC INFLUENCE",
    stack: "BRAND INFLUENCE / FRAMER",
    projectImageUrl: holisticImg.url,
    liveWebsiteUrl: "https://holistic-influence-487375.framer.app",
  },
  {
    idx: "04",
    title: "SABITH M A",
    stack: "PORTFOLIO / FRAMER",
    projectImageUrl: sabithImg.url,
    liveWebsiteUrl: "https://thankful-checkbox-910164.framer.app",
  },
];

export function WorkGallery() {
  return (
    <section id="works" className="relative border-b border-white/10 overflow-hidden">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,oklch(0.22_0.05_260/0.35),transparent_55%),radial-gradient(ellipse_at_bottom_right,oklch(0.25_0.08_30/0.30),transparent_60%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(180deg,transparent,oklch(0_0_0/0.4))]" />
        <div
          className="absolute inset-0 opacity-[0.07] mix-blend-overlay"
          style={{
            backgroundImage:
              "linear-gradient(to right, rgba(255,255,255,0.6) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.6) 1px, transparent 1px)",
            backgroundSize: "64px 64px",
          }}
        />
      </div>

      <div className="relative px-6 md:px-10 py-20 md:py-28">
        <SectionLabel index="01" label="SELECTED WORKS" />
        <h2 className="font-display font-bold uppercase text-5xl md:text-8xl leading-[0.9] tracking-tight mt-6 mb-16">
          Selected works <br />
          <span className="text-white/40">on loop.</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
          {works.map((w) => (
            <a
              key={w.idx}
              href={w.liveWebsiteUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group relative block overflow-hidden border border-white/10 hover:border-white/40 transition-colors aspect-[4/3] bg-white/[0.02]"
            >
              <img
                src={w.projectImageUrl}
                alt={w.title}
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover opacity-30 group-hover:opacity-60 transition-opacity duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-black/20 group-hover:from-black/90 group-hover:via-black/40 group-hover:to-transparent transition-all duration-500" />

              <div className="relative h-full flex flex-col justify-between p-6 md:p-8">
                <div className="flex items-center justify-between font-mono text-xs uppercase tracking-widest">
                  <span className="text-white/60">INDEX: {w.idx}</span>
                  <span className="text-white/60">{w.stack}</span>
                </div>
                <div>
                  <h3 className="font-display font-bold uppercase text-3xl md:text-5xl tracking-tight text-white/30 group-hover:text-white transition-colors duration-500">
                    {w.title}
                  </h3>
                  <div className="mt-4 overflow-hidden">
                    <span className="inline-block font-mono uppercase tracking-[0.3em] text-xs bg-white text-black px-4 py-2 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                      [ VISIT LIVE WEBSITE ↗ ]
                    </span>
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>

        <a
          href="#"
          className="mt-12 block border border-dashed border-white/30 hover:border-white hover:bg-white/5 transition-all py-10 md:py-14 text-center font-mono uppercase tracking-[0.3em] text-lg md:text-2xl text-white/80 hover:text-white"
        >
          [ ENTER THE ALAVA DESIGN VAULT ↗ ]
        </a>
      </div>
    </section>
  );
}

export function SectionLabel({ index, label }: { index: string; label: string }) {
  return (
    <div className="flex items-center gap-4 font-mono text-xs uppercase tracking-widest text-white/50">
      <span className="h-px w-10 bg-white/30" />
      <span>[ {index} // {label} ]</span>
    </div>
  );
}
